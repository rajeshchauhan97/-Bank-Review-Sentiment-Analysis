# utils.py
# This is a placeholder for utils.py